package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Luxury Gold Palette
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFFAA8C2C)
val GoldAccent = Color(0xFFFFD700)
val GoldBorder = Color(0x55D4AF37)
val GoldSubtle = Color(0x22D4AF37)

// Studio Dark Canvas
val DarkBg = Color(0xFF0B0B0B)
val CardBg = Color(0xFF141414)
val CardBgElevated = Color(0xFF1C1C1C)
val DarkBorder = Color(0xFF262626)

// Functional Status Colors
val EmeraldGreen = Color(0xFF10B981)
val EmeraldGreenLight = Color(0xFF34D399)
val AmberPending = Color(0xFFF59E0B)
val AmberPendingLight = Color(0xFFFBBF24)
val StudioBlue = Color(0xFF3B82F6)
val StudioBlueLight = Color(0xFF60A5FA)
val CrimsonRed = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
