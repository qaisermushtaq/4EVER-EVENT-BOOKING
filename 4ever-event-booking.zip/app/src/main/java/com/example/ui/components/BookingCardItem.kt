package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EventBooking
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CardBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookingCardItem(
    booking: EventBooking,
    onEdit: (EventBooking) -> Unit,
    onDelete: (EventBooking) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    val balance = booking.remainingBalance

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(14.dp))
            .border(1.dp, GoldBorder, RoundedCornerShape(14.dp))
            .padding(14.dp)
            .testTag("booking_card_${booking.id}"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Client Header & Status Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = booking.clientName,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                if (booking.clientPhone.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = booking.clientPhone,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Status Badge
            val isPaid = booking.isPaid
            val badgeBg = if (isPaid) EmeraldGreen.copy(alpha = 0.2f) else AmberPending.copy(alpha = 0.2f)
            val badgeText = if (isPaid) "PAID" else "DUE: Rs ${formatter.format(balance)}"
            val badgeColor = if (isPaid) EmeraldGreen else AmberPending

            Box(
                modifier = Modifier
                    .background(badgeBg, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = badgeText,
                    color = badgeColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 3-Column Pakistani Wedding Dates Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            DateColumn(title = "Mehndi", date = booking.mehndiDate)
            Box(modifier = Modifier.width(1.dp).height(28.dp).background(DarkBorder))
            DateColumn(title = "Barat", date = booking.baratDate)
            Box(modifier = Modifier.width(1.dp).height(28.dp).background(DarkBorder))
            DateColumn(title = "Valima", date = booking.valimaDate)
        }

        // Team & Location info
        if (booking.assignedTeam.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Group,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = booking.assignedTeam,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        if (booking.eventLocation.isNotBlank() || booking.eventTime.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (booking.eventLocation.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = booking.eventLocation,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }

                if (booking.eventTime.isNotBlank()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = booking.eventTime,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Equipment Tags (Photo, Video, Drone)
        val hasEquipment = booking.photoCamera.isNotBlank() || booking.videoCamera.isNotBlank() || booking.droneSelection.isNotBlank()
        if (hasEquipment) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (booking.photoCamera.isNotBlank()) {
                    EquipmentTag(icon = Icons.Default.Camera, text = booking.photoCamera)
                }
                if (booking.videoCamera.isNotBlank()) {
                    EquipmentTag(icon = Icons.Default.Videocam, text = booking.videoCamera)
                }
                if (booking.droneSelection.isNotBlank() && booking.droneSelection != "No Drone") {
                    EquipmentTag(icon = Icons.Default.Flight, text = booking.droneSelection)
                }
            }
        }

        HorizontalDivider(color = DarkBorder, thickness = 1.dp)

        // Bottom Row: Total financials & Quick Action buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Total: Rs ${formatter.format(booking.totalAmount)}",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                if (booking.advancePaid > 0) {
                    Text(
                        text = "Adv: Rs ${formatter.format(booking.advancePaid)}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            // Quick actions: Call, WhatsApp, Edit, Delete
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (booking.clientPhone.isNotBlank()) {
                    // Phone dial
                    IconButton(
                        onClick = { dialPhone(context, booking.clientPhone) },
                        modifier = Modifier.size(36.dp).testTag("call_client_${booking.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Call Client",
                            tint = EmeraldGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // WhatsApp link
                    IconButton(
                        onClick = { openWhatsApp(context, booking.clientPhone, booking.clientName) },
                        modifier = Modifier.size(36.dp).testTag("whatsapp_client_${booking.id}")
                    ) {
                        Text(
                            text = "WA",
                            color = EmeraldGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                IconButton(
                    onClick = { onEdit(booking) },
                    modifier = Modifier.size(36.dp).testTag("edit_booking_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Booking",
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = { onDelete(booking) },
                    modifier = Modifier.size(36.dp).testTag("delete_booking_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Booking",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DateColumn(title: String, date: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        Text(
            text = title,
            color = TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = date.ifBlank { "-" },
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun EquipmentTag(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String
) {
    Row(
        modifier = Modifier
            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .border(1.dp, GoldBorder.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldPrimary,
            modifier = Modifier.size(11.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 10.sp
        )
    }
}

private fun dialPhone(context: Context, phone: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$phone")
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not launch dialer: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openWhatsApp(context: Context, phone: String, clientName: String) {
    try {
        val cleanNumber = phone.replace(Regex("[^0-9]"), "")
        val message = Uri.encode("Hello $clientName! Greetings from 4ever Event Booking Studio.")
        val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=$message"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open WhatsApp: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
