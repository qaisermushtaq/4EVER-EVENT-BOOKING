package com.example.ui.dialogs

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.EventBooking
import com.example.ui.theme.AmberPending
import com.example.ui.theme.CardBg
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun BookingDialog(
    initialBooking: EventBooking,
    onDismiss: () -> Unit,
    onSave: (EventBooking) -> Unit,
    onLaunchContactPicker: () -> Unit
) {
    val context = LocalContext.current
    val isEdit = initialBooking.id != 0L

    var clientName by remember(initialBooking) { mutableStateOf(initialBooking.clientName) }
    var clientPhone by remember(initialBooking) { mutableStateOf(initialBooking.clientPhone) }
    var mehndiDate by remember(initialBooking) { mutableStateOf(initialBooking.mehndiDate) }
    var baratDate by remember(initialBooking) { mutableStateOf(initialBooking.baratDate) }
    var valimaDate by remember(initialBooking) { mutableStateOf(initialBooking.valimaDate) }

    var photoCamera by remember(initialBooking) { mutableStateOf(initialBooking.photoCamera) }
    var videoCamera by remember(initialBooking) { mutableStateOf(initialBooking.videoCamera) }
    var droneSelection by remember(initialBooking) { mutableStateOf(initialBooking.droneSelection) }

    var assignedTeam by remember(initialBooking) { mutableStateOf(initialBooking.assignedTeam) }
    var eventTime by remember(initialBooking) { mutableStateOf(initialBooking.eventTime) }
    var eventLocation by remember(initialBooking) { mutableStateOf(initialBooking.eventLocation) }

    var totalAmountStr by remember(initialBooking) {
        mutableStateOf(if (initialBooking.totalAmount > 0) initialBooking.totalAmount.toString() else "")
    }
    var advancePaidStr by remember(initialBooking) {
        mutableStateOf(if (initialBooking.advancePaid > 0) initialBooking.advancePaid.toString() else "")
    }

    val totalAmount = totalAmountStr.toLongOrNull() ?: 0L
    val advancePaid = advancePaidStr.toLongOrNull() ?: 0L
    val balance = (totalAmount - advancePaid).coerceAtLeast(0L)
    val formatter = NumberFormat.getNumberInstance(Locale.US)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .background(CardBg, RoundedCornerShape(16.dp))
                .border(1.dp, GoldBorder, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEdit) "Edit Booking" else "New Event Booking",
                        color = GoldPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Client Name
                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Client Name *", color = TextSecondary, fontSize = 11.sp) },
                    placeholder = { Text("e.g. Ali & Fatima", color = TextSecondary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_client_name_input"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                // Client Phone with Contact Picker Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = clientPhone,
                        onValueChange = { clientPhone = it },
                        label = { Text("Phone / WhatsApp", color = TextSecondary, fontSize = 11.sp) },
                        placeholder = { Text("+923001234567", color = TextSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("booking_phone_input"),
                        singleLine = true,
                        colors = customTextFieldColors()
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    TextButton(
                        onClick = onLaunchContactPicker,
                        modifier = Modifier.padding(top = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = "Pick Contact",
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Pick", color = GoldPrimary, fontSize = 11.sp)
                    }
                }

                // Event Dates (Mehndi, Barat, Valima)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .border(1.dp, GoldBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "EVENT DATES",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    DatePickerField(
                        label = "Mehndi Date",
                        value = mehndiDate,
                        onDateSelected = { mehndiDate = it },
                        context = context
                    )
                    DatePickerField(
                        label = "Barat Date",
                        value = baratDate,
                        onDateSelected = { baratDate = it },
                        context = context
                    )
                    DatePickerField(
                        label = "Valima Date",
                        value = valimaDate,
                        onDateSelected = { valimaDate = it },
                        context = context
                    )
                }

                // Cameras & Equipment Box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .border(1.dp, GoldBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "CAMERAS & EQUIPMENT",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )

                    DropdownSelector(
                        label = "Photo Camera",
                        selectedValue = photoCamera,
                        options = listOf("None", "Sony A7 IV", "Sony A7R V", "Canon EOS R6", "Canon 5D Mark IV", "Nikon Z8"),
                        onSelect = { photoCamera = if (it == "None") "" else it }
                    )

                    DropdownSelector(
                        label = "Video Camera",
                        selectedValue = videoCamera,
                        options = listOf("None", "Sony FX3", "Sony FX6", "Canon C70", "Panasonic S5II"),
                        onSelect = { videoCamera = if (it == "None") "" else it }
                    )

                    DropdownSelector(
                        label = "Drone",
                        selectedValue = droneSelection,
                        options = listOf("No Drone", "DJI Mavic 3 Pro", "DJI Mini 4 Pro", "DJI Air 3"),
                        onSelect = { droneSelection = if (it == "No Drone") "" else it }
                    )
                }

                // Assigned Team / Staff
                OutlinedTextField(
                    value = assignedTeam,
                    onValueChange = { assignedTeam = it },
                    label = { Text("Assigned Team / Staff", color = TextSecondary, fontSize = 11.sp) },
                    placeholder = { Text("Ahmed (Photo), Bilal (Video)", color = TextSecondary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_team_input"),
                    singleLine = true,
                    colors = customTextFieldColors()
                )

                // Venue & Event Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = eventTime,
                        onValueChange = { eventTime = it },
                        label = { Text("Event Time", color = TextSecondary, fontSize = 11.sp) },
                        placeholder = { Text("07:30 PM", color = TextSecondary) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = customTextFieldColors()
                    )

                    OutlinedTextField(
                        value = eventLocation,
                        onValueChange = { eventLocation = it },
                        label = { Text("Venue / Location", color = TextSecondary, fontSize = 11.sp) },
                        placeholder = { Text("Royal Palm Hall", color = TextSecondary) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = customTextFieldColors()
                    )
                }

                // Financials Box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .border(1.dp, GoldBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = totalAmountStr,
                            onValueChange = { totalAmountStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Total Package (Rs)", color = TextSecondary, fontSize = 11.sp) },
                            placeholder = { Text("150000", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("booking_total_amount_input"),
                            singleLine = true,
                            colors = customTextFieldColors()
                        )

                        OutlinedTextField(
                            value = advancePaidStr,
                            onValueChange = { advancePaidStr = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Advance Paid (Rs)", color = TextSecondary, fontSize = 11.sp) },
                            placeholder = { Text("50000", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("booking_advance_paid_input"),
                            singleLine = true,
                            colors = customTextFieldColors()
                        )
                    }

                    // Live Balance Preview
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Remaining Due Balance:",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "Rs ${formatter.format(balance)}",
                            color = if (balance == 0L && totalAmount > 0) Color(0xFF10B981) else AmberPending,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (clientName.isNotBlank()) {
                                onSave(
                                    initialBooking.copy(
                                        clientName = clientName.trim(),
                                        clientPhone = clientPhone.trim(),
                                        mehndiDate = mehndiDate,
                                        baratDate = baratDate,
                                        valimaDate = valimaDate,
                                        photoCamera = photoCamera,
                                        videoCamera = videoCamera,
                                        droneSelection = droneSelection,
                                        assignedTeam = assignedTeam.trim(),
                                        eventTime = eventTime.trim(),
                                        eventLocation = eventLocation.trim(),
                                        totalAmount = totalAmount,
                                        advancePaid = advancePaid
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = DarkBg),
                        shape = RoundedCornerShape(8.dp),
                        enabled = clientName.isNotBlank(),
                        modifier = Modifier.testTag("save_booking_submit_btn")
                    ) {
                        Text(
                            text = if (isEdit) "Update Booking" else "Save Booking",
                            color = DarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DatePickerField(
    label: String,
    value: String,
    onDateSelected: (String) -> Unit,
    context: Context
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBg, RoundedCornerShape(8.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            .clickable {
                showNativeDatePicker(context, value, onDateSelected)
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = label, color = TextSecondary, fontSize = 10.sp)
            Text(
                text = value.ifBlank { "Select date" },
                color = if (value.isNotBlank()) TextPrimary else TextSecondary.copy(alpha = 0.6f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Icon(
            imageVector = Icons.Default.CalendarToday,
            contentDescription = "Pick date",
            tint = GoldPrimary,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun DropdownSelector(
    label: String,
    selectedValue: String,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkBg, RoundedCornerShape(8.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                .clickable { expanded = true }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = label, color = TextSecondary, fontSize = 10.sp)
                Text(
                    text = selectedValue.ifBlank { "None" },
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = null,
                tint = GoldPrimary
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardBg)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = TextPrimary, fontSize = 12.sp) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun customTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = GoldPrimary,
    unfocusedBorderColor = DarkBorder,
    focusedContainerColor = DarkBg,
    unfocusedContainerColor = DarkBg,
    cursorColor = GoldAccent
)

private fun showNativeDatePicker(
    context: Context,
    currentDate: String,
    onDateSelected: (String) -> Unit
) {
    val cal = Calendar.getInstance()
    if (currentDate.isNotBlank()) {
        try {
            val parts = currentDate.split("-")
            if (parts.size == 3) {
                cal.set(Calendar.YEAR, parts[0].toInt())
                cal.set(Calendar.MONTH, parts[1].toInt() - 1)
                cal.set(Calendar.DAY_OF_MONTH, parts[2].toInt())
            }
        } catch (_: Exception) {}
    }

    DatePickerDialog(
        context,
        { _, y, m, d ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
            onDateSelected(formatted)
        },
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH),
        cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}
