package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.EventRepository
import com.example.data.model.EventBooking
import com.example.data.model.StudioBreak
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class BookingFilter {
    ALL,
    PENDING,
    COMPLETED,
    BREAKS
}

data class FinancialStats(
    val totalBookings: Int = 0,
    val totalEarned: Long = 0L,
    val pendingDues: Long = 0L,
    val breakDays: Int = 0
)

class EventBookingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: EventRepository

    val currentTimeString = MutableStateFlow("")

    val searchQuery = MutableStateFlow("")
    val activeFilter = MutableStateFlow(BookingFilter.ALL)

    // Calendar state (1-indexed month: 1 = Jan, 12 = Dec)
    val calendarYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val calendarMonth = MutableStateFlow(Calendar.getInstance().get(Calendar.MONTH) + 1)
    val selectedDate = MutableStateFlow<String?>(null)

    // Dialog state
    val bookingDialogState = MutableStateFlow<EventBooking?>(null) // null = closed, empty item = new, filled = edit
    val isBookingDialogOpen = MutableStateFlow(false)
    val isBreakDialogOpen = MutableStateFlow(false)
    val itemToDelete = MutableStateFlow<Pair<String, Long>?>(null) // ("booking"|"break", id)

    val allBookings: StateFlow<List<EventBooking>>
    val allBreaks: StateFlow<List<StudioBreak>>

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = EventRepository(database.eventDao())

        allBookings = repository.allBookings.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allBreaks = repository.allBreaks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Live clock loop
        viewModelScope.launch {
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            while (isActive) {
                currentTimeString.value = timeFormat.format(Date())
                delay(1000)
            }
        }
    }

    // Combined financial stats
    val financialStats: StateFlow<FinancialStats> = combine(allBookings, allBreaks) { bookings, breaks ->
        val totalCount = bookings.size
        val earned = bookings.sumOf { it.advancePaid }
        val dues = bookings.sumOf { it.remainingBalance }
        FinancialStats(
            totalBookings = totalCount,
            totalEarned = earned,
            pendingDues = dues,
            breakDays = breaks.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialStats())

    // Filtered bookings
    val filteredBookings: StateFlow<List<EventBooking>> = combine(
        allBookings,
        searchQuery,
        activeFilter,
        selectedDate
    ) { bookings, query, filter, dateFilter ->
        if (filter == BookingFilter.BREAKS) {
            return@combine emptyList()
        }

        bookings.filter { item ->
            val matchesSearch = query.isBlank() ||
                item.clientName.contains(query, ignoreCase = true) ||
                item.clientPhone.contains(query, ignoreCase = true) ||
                item.assignedTeam.contains(query, ignoreCase = true) ||
                item.eventLocation.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                BookingFilter.ALL -> true
                BookingFilter.PENDING -> item.remainingBalance > 0
                BookingFilter.COMPLETED -> item.isPaid
                BookingFilter.BREAKS -> false
            }

            val matchesDate = dateFilter == null || item.containsDate(dateFilter)

            matchesSearch && matchesFilter && matchesDate
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered breaks
    val filteredBreaks: StateFlow<List<StudioBreak>> = combine(
        allBreaks,
        searchQuery,
        selectedDate
    ) { breaks, query, dateFilter ->
        breaks.filter { item ->
            val matchesSearch = query.isBlank() ||
                item.reason.contains(query, ignoreCase = true) ||
                item.date.contains(query, ignoreCase = true)

            val matchesDate = dateFilter == null || item.date == dateFilter

            matchesSearch && matchesDate
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun setFilter(filter: BookingFilter) {
        activeFilter.value = filter
    }

    fun setSearch(query: String) {
        searchQuery.value = query
    }

    fun changeMonth(delta: Int) {
        var y = calendarYear.value
        var m = calendarMonth.value + delta
        if (m < 1) {
            m = 12
            y -= 1
        } else if (m > 12) {
            m = 1
            y += 1
        }
        calendarYear.value = y
        calendarMonth.value = m
    }

    fun selectDate(date: String?) {
        if (selectedDate.value == date) {
            selectedDate.value = null // toggle off
        } else {
            selectedDate.value = date
        }
    }

    fun openNewBookingDialog() {
        bookingDialogState.value = EventBooking(
            clientName = "",
            clientPhone = "+92",
            totalAmount = 0L,
            advancePaid = 0L
        )
        isBookingDialogOpen.value = true
    }

    fun openEditBookingDialog(booking: EventBooking) {
        bookingDialogState.value = booking
        isBookingDialogOpen.value = true
    }

    fun closeBookingDialog() {
        isBookingDialogOpen.value = false
        bookingDialogState.value = null
    }

    fun saveBooking(booking: EventBooking) {
        viewModelScope.launch {
            if (booking.id == 0L) {
                repository.insertBooking(booking)
            } else {
                repository.updateBooking(booking)
            }
            closeBookingDialog()
        }
    }

    fun openBreakDialog() {
        isBreakDialogOpen.value = true
    }

    fun closeBreakDialog() {
        isBreakDialogOpen.value = false
    }

    fun saveBreak(date: String, reason: String) {
        viewModelScope.launch {
            repository.insertBreak(StudioBreak(date = date, reason = reason))
            closeBreakDialog()
        }
    }

    fun confirmDelete(type: String, id: Long) {
        itemToDelete.value = Pair(type, id)
    }

    fun dismissDelete() {
        itemToDelete.value = null
    }

    fun executeDelete() {
        val target = itemToDelete.value ?: return
        viewModelScope.launch {
            if (target.first == "booking") {
                repository.deleteBookingById(target.second)
            } else {
                repository.deleteBreakById(target.second)
            }
            dismissDelete()
        }
    }
}
