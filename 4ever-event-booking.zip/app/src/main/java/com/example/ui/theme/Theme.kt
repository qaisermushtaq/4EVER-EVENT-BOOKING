package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = DarkBg,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = GoldLight,
    onSecondary = DarkBg,
    secondaryContainer = CardBgElevated,
    onSecondaryContainer = GoldLight,
    tertiary = StudioBlue,
    onTertiary = Color.White,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = CardBg,
    onSurface = TextPrimary,
    surfaceVariant = CardBgElevated,
    onSurfaceVariant = TextSecondary,
    outline = GoldBorder,
    outlineVariant = DarkBorder,
    error = CrimsonRed,
    onError = Color.White
)

@Composable
fun EventBookingTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
