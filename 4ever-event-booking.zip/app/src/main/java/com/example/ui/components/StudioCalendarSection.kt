package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EventBooking
import com.example.data.model.StudioBreak
import com.example.ui.theme.CardBg
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StudioBlueLight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale

@Composable
fun StudioCalendarSection(
    year: Int,
    month: Int, // 1..12
    bookings: List<EventBooking>,
    breaks: List<StudioBreak>,
    selectedDate: String?,
    onPrevMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onDateSelect: (String) -> Unit,
    onClearSelectedDate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val monthName = DateFormatSymbols(Locale.ENGLISH).months.getOrNull(month - 1) ?: ""

    // Calculate busy dates and break dates set
    val bookedDates = mutableSetOf<String>()
    bookings.forEach { b ->
        if (b.mehndiDate.isNotBlank()) bookedDates.add(b.mehndiDate)
        if (b.baratDate.isNotBlank()) bookedDates.add(b.baratDate)
        if (b.valimaDate.isNotBlank()) bookedDates.add(b.valimaDate)
    }
    val breakDates = breaks.map { it.date }.toSet()

    // Calendar day grid calculations
    val cal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month - 1)
        set(Calendar.DAY_OF_MONTH, 1)
    }
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    // Java DAY_OF_WEEK: Sunday=1, Monday=2 ... Saturday=7
    // We want Monday as start of week (Monday=0, Sunday=6)
    val firstDayOfWeek = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(16.dp))
            .border(1.dp, GoldBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Top row: Title and Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "STUDIO CALENDAR",
                    color = GoldPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LegendIndicator(color = EmeraldGreen, label = "Free")
                LegendIndicator(color = CrimsonRed, label = "Busy")
                LegendIndicator(color = StudioBlueLight, label = "Break")
            }
        }

        // Month Switcher Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .border(1.dp, GoldBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPrevMonth,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("calendar_prev_month")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = "Previous Month",
                    tint = GoldPrimary
                )
            }

            Text(
                text = "$monthName $year",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            IconButton(
                onClick = onNextMonth,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("calendar_next_month")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Next Month",
                    tint = GoldPrimary
                )
            }
        }

        // Selected Date Active Banner
        if (selectedDate != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GoldPrimary.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filtered by date: $selectedDate",
                    color = GoldAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                IconButton(
                    onClick = onClearSelectedDate,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear date filter",
                        tint = GoldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Days Header: Mon Tue Wed Thu Fri Sat Sun
        val dayHeaders = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            dayHeaders.forEach { header ->
                Text(
                    text = header,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Day Matrix
        val totalCells = firstDayOfWeek + daysInMonth
        val rows = (totalCells + 6) / 7

        for (row in 0 until rows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (col in 0..6) {
                    val cellIndex = row * 7 + col
                    val dayNumber = cellIndex - firstDayOfWeek + 1

                    if (dayNumber in 1..daysInMonth) {
                        val dateString = String.format(Locale.US, "%04d-%02d-%02d", year, month, dayNumber)
                        val isBooked = bookedDates.contains(dateString)
                        val isBreak = breakDates.contains(dateString)
                        val isSelected = selectedDate == dateString

                        val cellBg = when {
                            isSelected -> GoldPrimary.copy(alpha = 0.35f)
                            isBreak -> StudioBlueLight.copy(alpha = 0.25f)
                            isBooked -> CrimsonRed.copy(alpha = 0.25f)
                            else -> Color.Black.copy(alpha = 0.3f)
                        }

                        val cellBorder = when {
                            isSelected -> GoldAccent
                            isBreak -> StudioBlueLight
                            isBooked -> CrimsonRed
                            else -> DarkBorder
                        }

                        val textColor = when {
                            isSelected -> GoldAccent
                            isBreak -> StudioBlueLight
                            isBooked -> CrimsonRed
                            else -> TextSecondary
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .background(cellBg, RoundedCornerShape(6.dp))
                                .border(1.dp, cellBorder, RoundedCornerShape(6.dp))
                                .clickable { onDateSelect(dateString) }
                                .testTag("calendar_day_$dayNumber"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = dayNumber.toString(),
                                color = textColor,
                                fontSize = 11.sp,
                                fontWeight = if (isBooked || isBreak || isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    } else {
                        // Empty slot
                        Spacer(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendIndicator(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
