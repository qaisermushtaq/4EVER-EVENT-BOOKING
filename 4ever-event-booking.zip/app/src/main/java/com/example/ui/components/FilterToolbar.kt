package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FreeBreakfast
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BookingFilter
import com.example.ui.theme.CardBg
import com.example.ui.theme.DarkBg
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StudioBlueLight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FilterToolbar(
    activeFilter: BookingFilter,
    searchQuery: String,
    onFilterChange: (BookingFilter) -> Unit,
    onSearchChange: (String) -> Unit,
    onAddBreakClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(14.dp))
            .border(1.dp, GoldBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Filter pills row and Add Break button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChipItem(
                    label = "All",
                    isSelected = activeFilter == BookingFilter.ALL,
                    onClick = { onFilterChange(BookingFilter.ALL) },
                    tag = "filter_all"
                )
                FilterChipItem(
                    label = "Pending",
                    isSelected = activeFilter == BookingFilter.PENDING,
                    onClick = { onFilterChange(BookingFilter.PENDING) },
                    tag = "filter_pending"
                )
                FilterChipItem(
                    label = "Completed",
                    isSelected = activeFilter == BookingFilter.COMPLETED,
                    onClick = { onFilterChange(BookingFilter.COMPLETED) },
                    tag = "filter_completed"
                )
                FilterChipItem(
                    label = "Breaks",
                    isSelected = activeFilter == BookingFilter.BREAKS,
                    onClick = { onFilterChange(BookingFilter.BREAKS) },
                    tag = "filter_breaks"
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Add Break button
            Button(
                onClick = onAddBreakClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioBlueLight.copy(alpha = 0.2f),
                    contentColor = StudioBlueLight
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBlueLight.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("add_break_toolbar_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.FreeBreakfast,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Add Break",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Search text field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_events_input"),
            placeholder = {
                Text(
                    text = "Search client, phone, team, venue...",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GoldBorder.copy(alpha = 0.7f),
                focusedContainerColor = DarkBg,
                unfocusedContainerColor = DarkBg
            ),
            shape = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    val bg = if (isSelected) GoldPrimary else Color.Black.copy(alpha = 0.4f)
    val textColor = if (isSelected) DarkBg else TextSecondary
    val border = if (isSelected) GoldPrimary else GoldBorder

    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
