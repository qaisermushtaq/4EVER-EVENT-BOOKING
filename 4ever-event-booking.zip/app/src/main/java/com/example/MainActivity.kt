package com.example

import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.BookingFilter
import com.example.ui.EventBookingViewModel
import com.example.ui.components.BookingCardItem
import com.example.ui.components.BreakCardItem
import com.example.ui.components.FilterToolbar
import com.example.ui.components.HeaderBar
import com.example.ui.components.StatsGrid
import com.example.ui.components.StudioCalendarSection
import com.example.ui.dialogs.BookingDialog
import com.example.ui.dialogs.BreakDialog
import com.example.ui.dialogs.DeleteConfirmDialog
import com.example.ui.theme.CardBg
import com.example.ui.theme.DarkBg
import com.example.ui.theme.EventBookingTheme
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EventBookingTheme {
                EventBookingApp()
            }
        }
    }
}

@Composable
fun EventBookingApp(
    viewModel: EventBookingViewModel = viewModel()
) {
    val clockText by viewModel.currentTimeString.collectAsStateWithLifecycle()
    val stats by viewModel.financialStats.collectAsStateWithLifecycle()
    val activeFilter by viewModel.activeFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val year by viewModel.calendarYear.collectAsStateWithLifecycle()
    val month by viewModel.calendarMonth.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()

    val allBookings by viewModel.allBookings.collectAsStateWithLifecycle()
    val allBreaks by viewModel.allBreaks.collectAsStateWithLifecycle()
    val filteredBookings by viewModel.filteredBookings.collectAsStateWithLifecycle()
    val filteredBreaks by viewModel.filteredBreaks.collectAsStateWithLifecycle()

    val isBookingOpen by viewModel.isBookingDialogOpen.collectAsStateWithLifecycle()
    val bookingToEdit by viewModel.bookingDialogState.collectAsStateWithLifecycle()
    val isBreakOpen by viewModel.isBreakDialogOpen.collectAsStateWithLifecycle()
    val itemToDelete by viewModel.itemToDelete.collectAsStateWithLifecycle()

    // Contact Picker
    val context = androidx.compose.ui.platform.LocalContext.current
    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val cursor = context.contentResolver.query(uri, null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val nameCol = it.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                        val idCol = it.getColumnIndex(ContactsContract.Contacts._ID)
                        val name = if (nameCol != -1) it.getString(nameCol) else null
                        val id = if (idCol != -1) it.getString(idCol) else null

                        var phone = ""
                        if (id != null) {
                            val pCursor = context.contentResolver.query(
                                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                null,
                                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                arrayOf(id),
                                null
                            )
                            pCursor?.use { pc ->
                                if (pc.moveToFirst()) {
                                    val numCol = pc.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                                    if (numCol != -1) phone = pc.getString(numCol)
                                }
                            }
                        }

                        viewModel.bookingDialogState.value?.let { current ->
                            viewModel.bookingDialogState.value = current.copy(
                                clientName = if (current.clientName.isBlank() && !name.isNullOrBlank()) name else current.clientName,
                                clientPhone = if (phone.isNotBlank()) phone else current.clientPhone
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                // If permission is required by OEM, fallback gracefully
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = DarkBg,
        topBar = {
            HeaderBar(
                clockText = clockText,
                onNewBookingClick = { viewModel.openNewBookingDialog() }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openNewBookingDialog() },
                containerColor = GoldPrimary,
                contentColor = DarkBg,
                shape = CircleShape,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("fab_new_booking")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Booking",
                    tint = DarkBg,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Stats Grid
            item(key = "stats_grid") {
                StatsGrid(stats = stats)
            }

            // 2. Studio Calendar
            item(key = "calendar_section") {
                StudioCalendarSection(
                    year = year,
                    month = month,
                    bookings = allBookings,
                    breaks = allBreaks,
                    selectedDate = selectedDate,
                    onPrevMonth = { viewModel.changeMonth(-1) },
                    onNextMonth = { viewModel.changeMonth(1) },
                    onDateSelect = { date -> viewModel.selectDate(date) },
                    onClearSelectedDate = { viewModel.selectDate(null) }
                )
            }

            // 3. Filter Toolbar & Search
            item(key = "filter_toolbar") {
                FilterToolbar(
                    activeFilter = activeFilter,
                    searchQuery = searchQuery,
                    onFilterChange = { viewModel.setFilter(it) },
                    onSearchChange = { viewModel.setSearch(it) },
                    onAddBreakClick = { viewModel.openBreakDialog() }
                )
            }

            // 4. Section Title & Records Count Badge
            item(key = "records_header") {
                val countText = if (activeFilter == BookingFilter.BREAKS) {
                    "${filteredBreaks.size} Breaks"
                } else {
                    "${filteredBookings.size} Bookings"
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ListAlt,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "EVENT SCHEDULE & RECORDS",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(GoldPrimary.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .border(1.dp, GoldBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = countText,
                            color = GoldAccent,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // 5. Records List
            if (activeFilter == BookingFilter.BREAKS) {
                if (filteredBreaks.isEmpty()) {
                    item(key = "empty_breaks") {
                        EmptyStateView(
                            message = if (searchQuery.isNotBlank()) "No studio breaks match your search" else "No studio breaks or off-days recorded yet."
                        )
                    }
                } else {
                    items(filteredBreaks, key = { "break_${it.id}" }) { studioBreak ->
                        BreakCardItem(
                            studioBreak = studioBreak,
                            onDelete = { viewModel.confirmDelete("break", studioBreak.id) }
                        )
                    }
                }
            } else {
                if (filteredBookings.isEmpty()) {
                    item(key = "empty_bookings") {
                        EmptyStateView(
                            message = if (searchQuery.isNotBlank() || selectedDate != null) "No event bookings match your criteria" else "No event bookings yet. Tap '+ New' to create one!"
                        )
                    }
                } else {
                    items(filteredBookings, key = { "booking_${it.id}" }) { booking ->
                        BookingCardItem(
                            booking = booking,
                            onEdit = { viewModel.openEditBookingDialog(it) },
                            onDelete = { viewModel.confirmDelete("booking", it.id) }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Booking Dialog
    if (isBookingOpen && bookingToEdit != null) {
        BookingDialog(
            initialBooking = bookingToEdit!!,
            onDismiss = { viewModel.closeBookingDialog() },
            onSave = { updated -> viewModel.saveBooking(updated) },
            onLaunchContactPicker = { contactPickerLauncher.launch(null) }
        )
    }

    // Add Break Dialog
    if (isBreakOpen) {
        BreakDialog(
            onDismiss = { viewModel.closeBreakDialog() },
            onSave = { date, reason -> viewModel.saveBreak(date, reason) }
        )
    }

    // Delete Confirmation Dialog
    if (itemToDelete != null) {
        DeleteConfirmDialog(
            itemType = itemToDelete!!.first,
            onConfirm = { viewModel.executeDelete() },
            onDismiss = { viewModel.dismissDelete() }
        )
    }
}

@Composable
private fun EmptyStateView(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardBg, RoundedCornerShape(12.dp))
            .border(1.dp, GoldBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.EventBusy,
                contentDescription = null,
                tint = GoldPrimary.copy(alpha = 0.5f),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
