package com.example.data

import com.example.data.dao.EventDao
import com.example.data.model.EventBooking
import com.example.data.model.StudioBreak
import kotlinx.coroutines.flow.Flow

class EventRepository(private val dao: EventDao) {
    val allBookings: Flow<List<EventBooking>> = dao.getAllBookings()
    val allBreaks: Flow<List<StudioBreak>> = dao.getAllBreaks()

    suspend fun insertBooking(booking: EventBooking): Long {
        return dao.insertBooking(booking)
    }

    suspend fun updateBooking(booking: EventBooking) {
        dao.updateBooking(booking)
    }

    suspend fun deleteBooking(booking: EventBooking) {
        dao.deleteBooking(booking)
    }

    suspend fun deleteBookingById(id: Long) {
        dao.deleteBookingById(id)
    }

    suspend fun insertBreak(studioBreak: StudioBreak): Long {
        return dao.insertBreak(studioBreak)
    }

    suspend fun deleteBreak(studioBreak: StudioBreak) {
        dao.deleteBreak(studioBreak)
    }

    suspend fun deleteBreakById(id: Long) {
        dao.deleteBreakById(id)
    }
}
