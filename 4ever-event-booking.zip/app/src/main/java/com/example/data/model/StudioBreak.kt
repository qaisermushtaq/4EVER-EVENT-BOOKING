package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "studio_breaks")
data class StudioBreak(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,
    val reason: String,
    val createdAt: Long = System.currentTimeMillis()
)
