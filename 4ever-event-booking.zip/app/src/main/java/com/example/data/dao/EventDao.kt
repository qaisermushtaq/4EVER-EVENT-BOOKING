package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EventBooking
import com.example.data.model.StudioBreak
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM event_bookings ORDER BY id DESC")
    fun getAllBookings(): Flow<List<EventBooking>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: EventBooking): Long

    @Update
    suspend fun updateBooking(booking: EventBooking)

    @Delete
    suspend fun deleteBooking(booking: EventBooking)

    @Query("DELETE FROM event_bookings WHERE id = :id")
    suspend fun deleteBookingById(id: Long)

    @Query("SELECT COUNT(*) FROM event_bookings")
    suspend fun getBookingCount(): Int

    // Studio Breaks
    @Query("SELECT * FROM studio_breaks ORDER BY date ASC")
    fun getAllBreaks(): Flow<List<StudioBreak>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBreak(studioBreak: StudioBreak): Long

    @Delete
    suspend fun deleteBreak(studioBreak: StudioBreak)

    @Query("DELETE FROM studio_breaks WHERE id = :id")
    suspend fun deleteBreakById(id: Long)
}
