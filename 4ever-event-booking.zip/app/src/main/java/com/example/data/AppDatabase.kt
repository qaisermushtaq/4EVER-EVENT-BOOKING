package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.EventDao
import com.example.data.model.EventBooking
import com.example.data.model.StudioBreak
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Database(
    entities = [EventBooking::class, StudioBreak::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "event_booking_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.eventDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: EventDao) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val cal = Calendar.getInstance()

            cal.add(Calendar.DAY_OF_MONTH, 5)
            val mehndi1 = sdf.format(cal.time)
            cal.add(Calendar.DAY_OF_MONTH, 1)
            val barat1 = sdf.format(cal.time)
            cal.add(Calendar.DAY_OF_MONTH, 2)
            val valima1 = sdf.format(cal.time)

            cal.add(Calendar.DAY_OF_MONTH, 8)
            val mehndi2 = sdf.format(cal.time)
            cal.add(Calendar.DAY_OF_MONTH, 1)
            val barat2 = sdf.format(cal.time)
            cal.add(Calendar.DAY_OF_MONTH, 2)
            val valima2 = sdf.format(cal.time)

            cal.add(Calendar.DAY_OF_MONTH, -4)
            val breakDate = sdf.format(cal.time)

            // Seed initial sample events
            dao.insertBooking(
                EventBooking(
                    clientName = "Ali & Fatima",
                    clientPhone = "+923001234567",
                    mehndiDate = mehndi1,
                    baratDate = barat1,
                    valimaDate = valima1,
                    photoCamera = "Sony A7 IV",
                    videoCamera = "Sony FX3",
                    droneSelection = "DJI Mavic 3 Pro",
                    assignedTeam = "Ahmed (Photo), Bilal (Video)",
                    eventTime = "07:30 PM",
                    eventLocation = "Royal Palm Marquee, Lahore",
                    totalAmount = 180000L,
                    advancePaid = 80000L,
                    notes = "Traditional shoot with cinematic video teaser"
                )
            )

            dao.insertBooking(
                EventBooking(
                    clientName = "Hamza & Ayesha",
                    clientPhone = "+923219876543",
                    mehndiDate = mehndi2,
                    baratDate = barat2,
                    valimaDate = valima2,
                    photoCamera = "Canon EOS R6",
                    videoCamera = "Sony FX6",
                    droneSelection = "DJI Mini 4 Pro",
                    assignedTeam = "Usman (Photo), Zaid (Cinematography)",
                    eventTime = "08:00 PM",
                    eventLocation = "PC Hotel Grand Ballroom",
                    totalAmount = 240000L,
                    advancePaid = 240000L,
                    notes = "Full package paid in advance. 4K editing required."
                )
            )

            dao.insertBreak(
                StudioBreak(
                    date = breakDate,
                    reason = "Studio Lens Calibration & Off-Day"
                )
            )
        }
    }
}
