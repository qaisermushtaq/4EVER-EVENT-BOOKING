package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "event_bookings")
data class EventBooking(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientName: String,
    val clientPhone: String = "",
    val mehndiDate: String = "",
    val baratDate: String = "",
    val valimaDate: String = "",
    val photoCamera: String = "",
    val videoCamera: String = "",
    val droneSelection: String = "",
    val assignedTeam: String = "",
    val eventTime: String = "",
    val eventLocation: String = "",
    val totalAmount: Long = 0L,
    val advancePaid: Long = 0L,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingBalance: Long
        get() = (totalAmount - advancePaid).coerceAtLeast(0L)

    val isPaid: Boolean
        get() = totalAmount > 0L && remainingBalance == 0L

    fun containsDate(dateStr: String): Boolean {
        if (dateStr.isBlank()) return false
        return mehndiDate == dateStr || baratDate == dateStr || valimaDate == dateStr
    }
}
